<?php
if(!session_id()){
	session_start();
}

//Include Twitter config file && User class
include_once 'inConfig.php';
include_once 'User.class.php';

$authUrl = $output = '';

//If user already verified 
if(isset($_SESSION['oauth_status']) && $_SESSION['oauth_status'] == 'verified' && !empty($_SESSION['userData'])){
	//Prepare output to show to the user
	$userInfo = $_SESSION['userData'];
	$output = '<div class="login-form">
        <div class="head">
            <img src="'.$userInfo['picture'].'" alt=""/>
        </div>
        <form>
        <li>
            <p>'.$userInfo['first_name'].' '.$userInfo['last_name'].'</p>
        </li>
        <li>
            <p>'.$userInfo['headers'].'</p>
        </li>
        <li>
            <p>'.$userInfo['email'].'</p>
        </li>
	<li>
            <p>'.$userInfo['locale'].'</p>
        </li>        
            <input type="hidden" name="skills" id="skills'.$userInfo['id'].'" value="'.$userInfo['skills'].'">
        
        <div class="foot">            
            <a href="'.$userInfo['link'].'" target="_blank">View Profile</a>
            <a href="#" id="jobs_search" >Search Jobs</a>
            <a style="margin-left: 75px;" href="logout.php">Logout</a>
            <div class="clear"> </div> 
        </div>
        </form>
	</div>';
}elseif((isset($_GET["oauth_init"]) && $_GET["oauth_init"] == 1) || (isset($_GET['oauth_token']) && isset($_GET['oauth_verifier']))){
	$client = new oauth_client_class;
	
	$client->client_id = $apiKey;
	$client->client_secret = $apiSecret;
	$client->redirect_uri = $redirectURL;
	$client->scope = $scope;
	$client->debug = false;
	$client->debug_http = true;
	$application_line = __LINE__;
	
	if(strlen($client->client_id) == 0 || strlen($client->client_secret) == 0){
		die('Please go to LinkedIn Apps page https://www.linkedin.com/secure/developer?newapp= , '.
			'create an application, and in the line '.$application_line.
			' set the client_id to Consumer key and client_secret with Consumer secret. '.
			'The Callback URL must be '.$client->redirect_uri.'. Make sure you enable the '.
			'necessary permissions to execute the API calls your application needs.');
	}
	
	
	if($success = $client->Initialize()){            
		if(($success = $client->Process())){
                    
			if(strlen($client->authorization_error)){
				$client->error = $client->authorization_error;
				$success = false;
			}elseif(strlen($client->access_token)){                            
				$success = $client->CallAPI('http://api.linkedin.com/v1/people/~:(id,email-address,first-name,last-name,location,picture-url,public-profile-url,formatted-name,skills,interests,publications,patents,headline,phone-numbers)', 
				'GET',
				array('format'=>'json'),
				array('FailOnAccessError'=>true), $userInfo);
			}
                        //print_r($userInfo);die;
		}
               
		$success = $client->Finalize($success);
                 //print_r($success);die;
	}
	
	if($client->exit) exit;
	
	if($success){
		//Initialize User class
		$user = new User();
		//echo"<pre>";print_r($userInfo);die;
		//Insert or update user data to the database
		$fname = $userInfo->firstName;
		$lname = $userInfo->lastName;
		$inUserData = array(
			'oauth_provider'=> 'linkedin',
			'oauth_uid'     => $userInfo->id,
			'first_name'    => $fname,
			'last_name'     => $lname,
			'email'         => $userInfo->emailAddress,
			'gender'        => '',
			'locale'        => $userInfo->location->name,
			'picture'       => $userInfo->pictureUrl,
			'link'          => $userInfo->publicProfileUrl,
			'username'		=> '',
                        'headers'       =>$userInfo->headline,
                        'skills'       =>$userInfo->skills
		);
		
		$userData = $user->checkUser($inUserData);
		
		//Storing user data into session
		$_SESSION['userData'] = $userData;
		$_SESSION['oauth_status'] = 'verified';
		header('Location: ./');
	}else{
		 $output = '<h3 style="color:red">Error connecting to LinkedIn! try again later!</h3>';
	}
}elseif(isset($_GET["oauth_problem"]) && $_GET["oauth_problem"] <> ""){
	$output = '<h3 style="color:red">'.$_GET["oauth_problem"].'</h3>';
}else{
	$authUrl = '?oauth_init=1';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/style.css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>  
</head>
<body>
<?php echo $output; ?>
<?php
if(!empty($authUrl)){
	echo '<div class="linkedin_btn"><a href="'.$authUrl.'"><img src="images/sign-in-with-linkedin.png" /></a></div>';
}
?>
</body>  
</html>
<script  type="text/javascript">
    var id = <?php echo $userInfo['id']; ?>;
    //alert(id);
 $("#jobs_search").click(function(){
    var skills = $('#skills'+id).val();
   // alert(skills);
    var url1 = "https://www.naukri.com/";
    var url2 = skills+"-jobs";
    var a = "123";
    var b = "465";
    var url = url1+''+url2;
    //alert(url);
    window.location = url;

}); 
</script>
