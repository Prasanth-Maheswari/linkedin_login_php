<?php 
require_once 'src/http.php';
require_once 'src/oauth_client.php';


$apiKey = '813psnkrjz2o7b';
$apiSecret = 'A3d57iY7s9eMQ3AJ';
$redirectURL = 'http://localhost/linkedin_login_php/';
$scope = 'r_basicprofile r_emailaddress'; 
?>